This product is the software needed to connect a lcd display and IR remote receiver to the karadio project.
It will be improved to connect a KY040 rotary encoder.
https://github.com/karawin/Ka-Radio
https://hackaday.io/project/11570-wifi-webradio-with-esp8266-and-vs1053

It run on a stm32 bluePill board.

The wiring and other important infos and warnings are at the end of the ucglibConf.h file.

If you use an IR remote control, please uncomment the #define IR at the beginning of the ino file.
