This product is the software needed to connect a lcd display and IR remote receiver to the karadio project.
It run on an arduino pro mini or clone.
If the lcd is a 3.3 volts version; please use the 3.3V 8Mhz, and if the lcd is 5v, use the 5V 16Mhz version.
The IR is 3.3 or 5v tolerant.

The wiring and other important infos and warnings are at the end of the u8glibConf.h file.

If you use an IR remote control, please uncomment the #define IR at the beginning of the karadioU8glib.ino file
and be sure to read carefully the u8glibConf.h file.
